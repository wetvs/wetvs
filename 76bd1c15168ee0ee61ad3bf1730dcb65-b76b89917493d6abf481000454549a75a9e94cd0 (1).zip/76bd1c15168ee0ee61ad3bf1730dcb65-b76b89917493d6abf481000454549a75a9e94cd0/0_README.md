# Google Calendar - Public Holiday Calendars 

calendarID from `cal.csv` can be used at path param in
https://developers.google.com/calendar/v3/reference/calendars/get
https://developers.google.com/calendar/v3/reference/events/list